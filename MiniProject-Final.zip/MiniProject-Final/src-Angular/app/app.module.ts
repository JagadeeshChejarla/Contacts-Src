import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {ContactsService} from './contacts.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UpdateContactsComponent } from './update-contacts/update-contacts.component';
import { ViewAllContactsComponent } from './view-all-contacts/view-all-contacts.component';
import { AddContactsComponent } from './add-contacts/add-contacts.component';
import { GetcontactComponent } from './getcontact/getcontact.component';
import { DeletecontactComponent } from './deletecontact/deletecontact.component';


@NgModule({
  declarations: [
    AppComponent,
    UpdateContactsComponent,
    ViewAllContactsComponent,
    AddContactsComponent,
    GetcontactComponent,
    DeletecontactComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule
  ],
  providers: [ContactsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
