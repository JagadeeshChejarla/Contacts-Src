import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-update-contacts',
  templateUrl: './update-contacts.component.html',
  styleUrls: ['./update-contacts.component.css']
})
export class UpdateContactsComponent implements OnInit {

  conn: Contact = new Contact();
  constructor(private service : ContactsService) { 
  }

  ngOnInit(): void {
  }
  updateContacts(){
    this.service.updateContact(this.conn).subscribe(data =>{ 
      if(data != null) {
        alert("Updated Successfully");
      }
    });
  }
}
