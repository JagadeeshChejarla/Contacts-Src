import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-deletecontact',
  templateUrl: './deletecontact.component.html',
  styleUrls: ['./deletecontact.component.css']
})
export class DeletecontactComponent implements OnInit {

  conn: Contact = new Contact();
  constructor(private service: ContactsService){
    this.conn.contactName=" ";
  }
  

  ngOnInit(): void {
   
  }
  deleteContact(){
    console.log(this.conn.contactName);
    this.service.deleteContacts(this.conn.contactName)
    .subscribe((data: Contact) => {
        this.conn = data;
   
    });
    alert("Deleted Successfully");
  }

}