import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-view-all-contacts',
  templateUrl: './view-all-contacts.component.html',
  styleUrls: ['./view-all-contacts.component.css']
})
export class ViewAllContactsComponent implements OnInit {
  data: any;
  conn: Contact = new Contact();
  constructor(private service:ContactsService){
    
  }
 
  ngOnInit(){
 this.getAllContacts();
}
getAllContacts(){
  this.service.getContacts().subscribe(data =>{
    this.data=data;
})
}
}
