package com.contacts;


import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/Contacts")

public class ContactList {

	@GET
    @Produces( MediaType.APPLICATION_JSON)
public List<Contact>getContacts(){
	List<Contact>listOfContacts=ContactDao.getAllContact();
	return listOfContacts;
	
}

    @GET
    @Path("/{ContactName}")
    @Produces( MediaType.APPLICATION_JSON)
    public Contact getContact(@PathParam("ContactName") String ContactName) {
        return ContactDao.getContact(ContactName);
    } 

    @POST
    //@Path("/add")
    @Produces( MediaType.APPLICATION_JSON)
    public Contact addContact(Contact cont) {
        return ContactDao.addContact(cont);
    }
    @PUT
   // @Path("/update")
    @Produces( MediaType.APPLICATION_JSON)
    public Contact updateContact(Contact cont) {
        return ContactDao.updateContact(cont);
    }
 
    @DELETE
    @Path("/{contactName}")
    @Produces( MediaType.APPLICATION_JSON)
    public void deleteContact(@PathParam("contactName") String contactName) {
        ContactDao.deleteContact(contactName);
    }

}
